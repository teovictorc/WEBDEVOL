-- --------------------------------------------------------
-- Servidor:                     192.168.10.251
-- Versão do servidor:           5.1.49-community - MySQL Community Server (GPL)
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para dbWEBDEVOL
CREATE DATABASE IF NOT EXISTS `dbwebdevol` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dbWEBDEVOL`;


-- Copiando estrutura para tabela dbWEBDEVOL.1_itempedidocompra
CREATE TABLE IF NOT EXISTS `1_itempedidocompra` (
  `CodLoja` char(3) NOT NULL,
  `NumeroPedido` varchar(6) NOT NULL,
  `Referencia` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.1_notafiscal
CREATE TABLE IF NOT EXISTS `1_notafiscal` (
  `CodFornecedor` int(11) NOT NULL,
  `CodLoja` char(3) NOT NULL,
  `NumeroNFiscalRecebimento` varchar(6) NOT NULL,
  `SerieNFiscalRecebimento` varchar(5) NOT NULL,
  `DataEmissaoNotaFiscal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.1_notafiscal_item
CREATE TABLE IF NOT EXISTS `1_notafiscal_item` (
  `CodFornecedor` int(11) NOT NULL,
  `SerieNFiscalRecebimento` varchar(5) NOT NULL,
  `NumeroNFiscalRecebimento` varchar(6) NOT NULL,
  `SequencialRecebimento` int(11) NOT NULL,
  `Referencia` varchar(30) NOT NULL,
  `QuantidadeFisicaContada` decimal(14,6) NOT NULL,
  `PrecoUnitarioNotaFiscal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.1_pedidocompra
CREATE TABLE IF NOT EXISTS `1_pedidocompra` (
  `NumeroPedido` varchar(6) NOT NULL,
  `CodFornecedor` int(11) NOT NULL,
  `DT_EMIS_NF` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.2_itemnotafiscal
CREATE TABLE IF NOT EXISTS `2_itemnotafiscal` (
  `CodFornecedor` int(11) NOT NULL,
  `SerieNFiscalRecebimento` varchar(5) NOT NULL,
  `NumeroNFiscalRecebimento` varchar(6) NOT NULL,
  `SequencialRecebimento` int(11) NOT NULL,
  `Referencia` varchar(30) NOT NULL,
  `QuantidadeFisicaContada` decimal(14,6) NOT NULL,
  `PrecoUnitarioNotaFiscal` decimal(10,2) NOT NULL,
  `PrecoUnitarioPedido` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.2_notafiscal
CREATE TABLE IF NOT EXISTS `2_notafiscal` (
  `CodFornecedor` int(11) NOT NULL,
  `CodLoja` char(3) NOT NULL,
  `NumeroNFiscalRecebimento` varchar(6) NOT NULL,
  `SerieNFiscalRecebimento` varchar(5) NOT NULL,
  `DataEmissaoNotaFiscal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.aaa_nota_fiscal
CREATE TABLE IF NOT EXISTS `aaa_nota_fiscal` (
  `PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `SERIE_NF` char(3) NOT NULL,
  `NUM_NF` decimal(6,0) NOT NULL DEFAULT '0',
  `PESSOA_DESTINATARIO` decimal(10,0) NOT NULL DEFAULT '0',
  `DT_EMIS_NF` date NOT NULL DEFAULT '0000-00-00',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.aaa_nota_fiscal_item
CREATE TABLE IF NOT EXISTS `aaa_nota_fiscal_item` (
  `PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `SERIE_NF` char(3) NOT NULL,
  `NUM_NF` decimal(6,0) NOT NULL DEFAULT '0',
  `NUM_SEQC_NF` decimal(3,0) NOT NULL DEFAULT '0',
  `CD_ITEM_MATERIAL` varchar(16) DEFAULT NULL,
  `CD_COLECAO` varchar(4) DEFAULT NULL,
  `LANCAMENTO` char(2) DEFAULT NULL,
  `CLASSIFICACAO_FISCAL` varchar(11) DEFAULT NULL,
  `UNIDADE_MEDIDA` varchar(10) DEFAULT NULL,
  `TL_ITEM` decimal(10,2) DEFAULT NULL,
  `VL_UNITARIO_ITEM` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ALIQ_ICMS` decimal(10,2) DEFAULT NULL,
  `VL_ROYL_CLIN_NORMAL` decimal(15,2) DEFAULT '0.00',
  `ALIQ_IPI` decimal(15,2) DEFAULT '0.00',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  `LINHA` varchar(6) DEFAULT NULL,
  `MODELO` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.creditos_pagos
CREATE TABLE IF NOT EXISTS `creditos_pagos` (
  `pessoa` int(10) unsigned NOT NULL DEFAULT '0',
  `serie_nf` char(3) NOT NULL,
  `num_nf` int(6) unsigned NOT NULL DEFAULT '0',
  `cgccpf` varchar(19) DEFAULT NULL,
  `data_devolucao` date DEFAULT NULL,
  `valor_nota` decimal(15,2) unsigned DEFAULT NULL,
  `empresa` varchar(20) DEFAULT NULL,
  `valor_pago` decimal(15,2) unsigned DEFAULT NULL,
  `data_liquidacao` date DEFAULT NULL,
  `FORMA_PAGAMENTO` varchar(50) DEFAULT NULL,
  `BANCO` char(3) DEFAULT NULL,
  `AGENCIA_CODIGO` varchar(5) DEFAULT NULL,
  `AGENCIA_NOME` varchar(30) DEFAULT NULL,
  `CONTA` varchar(20) DEFAULT NULL,
  `TITULAR` varchar(50) DEFAULT NULL,
  `Categoria` char(1) DEFAULT '1',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  PRIMARY KEY (`pessoa`,`serie_nf`,`num_nf`),
  KEY `I_CREDITOS_PAGOS_PESSOA` (`pessoa`,`num_nf`),
  KEY `I_Categoria_CD_UNIDADE` (`Categoria`,`CD_UNIDADE_DE_N`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.duplicata
CREATE TABLE IF NOT EXISTS `duplicata` (
  `PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `SERIE_NF` char(3) NOT NULL,
  `NUM_NF` varchar(6) NOT NULL,
  `PARCELA` decimal(2,0) NOT NULL DEFAULT '0',
  `DT_EMISSAO` date DEFAULT NULL,
  `DT_VENCIMENTO` date DEFAULT NULL,
  `VL_DUPL` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`PESSOA_EMITENTE`,`SERIE_NF`,`NUM_NF`,`PARCELA`),
  KEY `IDX_PESSOA_EMITENTE` (`PESSOA_EMITENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.ido
CREATE TABLE IF NOT EXISTS `ido` (
  `ido` bigint(5) NOT NULL DEFAULT '1',
  `nota_debito` bigint(20) NOT NULL DEFAULT '1',
  `rar_comercial` varchar(20) NOT NULL DEFAULT '0',
  `rar_pdv` varchar(20) NOT NULL DEFAULT '1',
  `hora_inicial` datetime DEFAULT NULL,
  `rar_iaf` varchar(20) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.item_material
CREATE TABLE IF NOT EXISTS `item_material` (
  `CD_ITEM_MATERIAL` varchar(16) NOT NULL DEFAULT '',
  `DS_RESUMIDA_ITEM` varchar(100) DEFAULT NULL,
  `RF_MATERIAL` varchar(16) DEFAULT NULL,
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  `LINHA` varchar(6) DEFAULT NULL,
  `MODELO` varchar(6) DEFAULT NULL,
  `FABRICANTE` varchar(25) DEFAULT NULL,
  KEY `CD_ITEM_MATERIAL` (`CD_ITEM_MATERIAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.item_nota_fiscal
CREATE TABLE IF NOT EXISTS `item_nota_fiscal` (
  `PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `SERIE_NF` varchar(10) NOT NULL,
  `NUM_NF` varchar(10) NOT NULL DEFAULT '0',
  `NUM_SEQC_NF` decimal(3,0) NOT NULL DEFAULT '0',
  `CD_ITEM_MATERIAL` varchar(16) DEFAULT NULL,
  `CD_COLECAO` varchar(10) DEFAULT NULL,
  `LANCAMENTO` char(2) DEFAULT NULL,
  `CLASSIFICACAO_FISCAL` varchar(11) DEFAULT NULL,
  `UNIDADE_MEDIDA` varchar(10) DEFAULT NULL,
  `TL_ITEM` decimal(10,2) DEFAULT NULL,
  `VL_UNITARIO_ITEM` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ALIQ_ICMS` decimal(10,2) DEFAULT NULL,
  `VL_ROYL_CLIN_NORMAL` decimal(15,2) DEFAULT '0.00',
  `ALIQ_IPI` decimal(15,2) DEFAULT '0.00',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  `LINHA` varchar(6) DEFAULT NULL,
  `MODELO` varchar(6) DEFAULT NULL,
  KEY `ID_ITEM_NF_1` (`NUM_NF`,`SERIE_NF`,`CD_ITEM_MATERIAL`),
  KEY `ID_ITEM_NF_2` (`NUM_NF`,`SERIE_NF`,`PESSOA_EMITENTE`),
  KEY `IDX_NF_ITEM_01` (`PESSOA_EMITENTE`,`SERIE_NF`,`NUM_NF`,`NUM_SEQC_NF`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.item_pedido_compra
CREATE TABLE IF NOT EXISTS `item_pedido_compra` (
  `CD_ITEM_COMPRA` varchar(17) NOT NULL DEFAULT '0',
  `PESSOA_EMPRESA` decimal(10,0) NOT NULL DEFAULT '1',
  `NUM_PEDD_COMPRA` decimal(10,0) NOT NULL DEFAULT '0',
  `CD_ITEM_MATERIAL` varchar(16) DEFAULT NULL,
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  KEY `PRIMARIO` (`NUM_PEDD_COMPRA`,`PESSOA_EMPRESA`),
  KEY `CD_ITEM_COMPRA` (`CD_ITEM_COMPRA`),
  KEY `CD_ITEM_MATERIAL` (`CD_ITEM_MATERIAL`),
  KEY `IDX_ITEM_PEDIDO_COMPRA_01` (`CD_ITEM_MATERIAL`),
  KEY `idx_item_pedido_compra` (`CD_ITEM_MATERIAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.nota_fiscal
CREATE TABLE IF NOT EXISTS `nota_fiscal` (
  `PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `SERIE_NF` char(10) NOT NULL,
  `NUM_NF` varchar(10) NOT NULL DEFAULT '0',
  `PESSOA_DESTINATARIO` decimal(10,0) NOT NULL DEFAULT '0',
  `DT_EMIS_NF` date NOT NULL DEFAULT '0000-00-00',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.operacao
CREATE TABLE IF NOT EXISTS `operacao` (
  `CD_OPER` varchar(5) NOT NULL DEFAULT '0',
  `DS_OPER` varchar(30) DEFAULT NULL,
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  PRIMARY KEY (`CD_OPER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.pedido_compra
CREATE TABLE IF NOT EXISTS `pedido_compra` (
  `PESSOA_EMPRESA` varchar(12) NOT NULL DEFAULT '1',
  `NUM_PEDD_COMPRA` varchar(12) NOT NULL DEFAULT '0',
  `PESSOA_FORNECEDOR` decimal(10,0) DEFAULT NULL,
  `DT_EMISSAO` date NOT NULL DEFAULT '0000-00-00',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  KEY `id_pessoa_empresa_compra` (`PESSOA_EMPRESA`),
  KEY `id_pessoA_FORNECEDOR` (`PESSOA_FORNECEDOR`),
  KEY `PESSOA_EMPRESA` (`PESSOA_EMPRESA`,`NUM_PEDD_COMPRA`),
  KEY `idx_pedido_compra` (`NUM_PEDD_COMPRA`),
  KEY `NUM_PEDD_COMPRA` (`NUM_PEDD_COMPRA`,`PESSOA_FORNECEDOR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.pesquisa_satisfacao
CREATE TABLE IF NOT EXISTS `pesquisa_satisfacao` (
  `PESQ_PESSOA` varchar(5) NOT NULL DEFAULT '0',
  `PESQ_NOME` varchar(50) NOT NULL DEFAULT '',
  `PESQ_RESPONSAVEL` varchar(50) NOT NULL DEFAULT '',
  `PESQ_PERGUNTA1` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA2` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA3` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA4` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA5` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA6` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA7` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA8` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA9` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA10` int(11) NOT NULL DEFAULT '0',
  `PESQ_PERGUNTA11` int(11) NOT NULL DEFAULT '0',
  `PESQ_COMENTARIO` text,
  `PESQ_APROVADO` char(1) NOT NULL DEFAULT 'N',
  `PESQ_DATA` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`PESQ_PESSOA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.pessoa
CREATE TABLE IF NOT EXISTS `pessoa` (
  `pessoa` decimal(10,0) NOT NULL,
  `cgccpf` varchar(19) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `Logradouro` varchar(50) DEFAULT NULL,
  `Complemento` varchar(50) DEFAULT NULL,
  `Bairro` varchar(30) DEFAULT NULL,
  `nm_municipio` varchar(40) DEFAULT NULL,
  `sg_uf` varchar(2) DEFAULT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `ie` varchar(20) DEFAULT NULL,
  `ecliente` varchar(1) NOT NULL DEFAULT 'S',
  `CLIENTE_ATIVO` varchar(1) NOT NULL DEFAULT 'S',
  `EFORNECEDOR` char(1) NOT NULL DEFAULT 'N',
  `FORNECEDOR_ATIVO` char(1) NOT NULL DEFAULT 'N',
  `categoria_cliente` varchar(1) NOT NULL DEFAULT '8',
  `cep` varchar(10) DEFAULT NULL,
  `SUFR_BENF_ICMS` varchar(1) DEFAULT 'N',
  `fantasia` varchar(50) DEFAULT NULL,
  UNIQUE KEY `pessoa` (`pessoa`),
  KEY `idx_pessoa` (`pessoa`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.pessoa_arezzo
CREATE TABLE IF NOT EXISTS `pessoa_arezzo` (
  `PESSOA` decimal(10,0) NOT NULL DEFAULT '0',
  `CGCCPF` varchar(19) DEFAULT NULL,
  `NOME` varchar(80) DEFAULT NULL,
  `LOGRADOURO` varchar(50) DEFAULT NULL,
  `COMPLEMENTO` varchar(50) DEFAULT NULL,
  `BAIRRO` varchar(20) DEFAULT NULL,
  `NM_MUNICIPIO` varchar(40) DEFAULT NULL,
  `SG_UF` char(2) DEFAULT NULL,
  `CEP` varchar(10) DEFAULT NULL,
  `EMAIL` varchar(40) DEFAULT NULL,
  `ECLIENTE` char(1) DEFAULT NULL,
  `EFORNECEDOR` char(1) DEFAULT NULL,
  `IE` varchar(15) DEFAULT NULL,
  `CATEGORIA_CLIENTE` decimal(10,0) DEFAULT NULL,
  `CLIENTE_ATIVO` char(1) DEFAULT NULL,
  `PESSOA_SUPERVISAO_REPR` varchar(10) DEFAULT NULL,
  `FORNECEDOR_ATIVO` char(1) DEFAULT NULL,
  `OPTT_SIMPLES_ESTD` char(1) DEFAULT NULL,
  `SUFR_BENF_ICMS` char(1) DEFAULT NULL,
  `CD_UNIDADE_DE_N` varchar(3) DEFAULT NULL,
  `CD_EMPRESA_ANTIGO` decimal(10,0) DEFAULT NULL,
  `GRUPO_EMPRESARIAL` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`PESSOA`),
  KEY `NOME` (`NOME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.produtos_recebidos
CREATE TABLE IF NOT EXISTS `produtos_recebidos` (
  `pessoa_empresa_resp_proc` int(10) unsigned NOT NULL DEFAULT '0',
  `pessoa_emitente` int(10) unsigned NOT NULL DEFAULT '0',
  `dt_emis_nf` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_saida_entrada` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tl_item` bigint(20) unsigned NOT NULL DEFAULT '0',
  `unidade_medida` varchar(10) DEFAULT NULL,
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  KEY `idx_dt_saida_entrada` (`dt_saida_entrada`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_acesso
CREATE TABLE IF NOT EXISTS `rar_acesso` (
  `ACESS_IDO` varchar(20) NOT NULL DEFAULT '',
  `ACESS_TIPOACESSO` char(1) DEFAULT NULL,
  `ACESS_USUAR_IDO` varchar(20) DEFAULT NULL,
  `ACESS_PROGR_CODIGO` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ACESS_IDO`),
  UNIQUE KEY `PK_ACESS_IDO` (`ACESS_IDO`),
  KEY `ID_ACESSO1` (`ACESS_USUAR_IDO`),
  KEY `FK_RAR_ACESSO_PROGR_CODIGO` (`ACESS_PROGR_CODIGO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_agente
CREATE TABLE IF NOT EXISTS `rar_agente` (
  `AGENT_IDO` varchar(20) NOT NULL DEFAULT '',
  `AGENT_NOME` varchar(50) DEFAULT NULL,
  `AGENT_EMAIL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`AGENT_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_anjo_coordenador
CREATE TABLE IF NOT EXISTS `rar_anjo_coordenador` (
  `ANJCO_IDO` varchar(20) NOT NULL DEFAULT '',
  `ANJCO_PESSOA` varchar(20) DEFAULT NULL,
  `ANJCO_USUAR_IDO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ANJCO_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_autorizacao
CREATE TABLE IF NOT EXISTS `rar_autorizacao` (
  `AUTOR_NUMAUT` varchar(9) NOT NULL DEFAULT '',
  `AUTOR_DATAAUTORIZACAO` date DEFAULT NULL,
  PRIMARY KEY (`AUTOR_NUMAUT`),
  UNIQUE KEY `PK_AUTOR_NUMAUT` (`AUTOR_NUMAUT`),
  KEY `ID_AUTOR1` (`AUTOR_DATAAUTORIZACAO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_avaliacao
CREATE TABLE IF NOT EXISTS `rar_avaliacao` (
  `AVALI_NUMRAR` varchar(12) NOT NULL DEFAULT '',
  `AVALI_AREZ_DEFEI_IDO` varchar(20) DEFAULT NULL,
  `AVALI_AREZ_USUAR_IDO` varchar(20) DEFAULT NULL,
  `AVALI_AREZ_DATA` date DEFAULT NULL,
  `AVALI_AREZ_ENCERRADO` char(1) DEFAULT 'N',
  `AVALI_AREZ_DETALHE` blob,
  `AVALI_SITUACAO` char(1) DEFAULT NULL,
  `AVALI_AUTOR_NUMAUT` varchar(9) DEFAULT NULL,
  `AVALI_AREZ_DEFEIG_IDO` varchar(20) DEFAULT NULL,
  `AVALI_AREZ_DEFEIS_IDO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`AVALI_NUMRAR`),
  UNIQUE KEY `PK_AVALI_NUMRAR` (`AVALI_NUMRAR`),
  KEY `ID_AVALIACAO1` (`AVALI_SITUACAO`),
  KEY `ID_AVALIACAO6` (`AVALI_SITUACAO`,`AVALI_AREZ_DATA`),
  KEY `FK_RAR_AVALIACAO_USUAR_IDO_ARZ` (`AVALI_AREZ_USUAR_IDO`),
  KEY `FK_RAR_AVALIACAO_DEFEI_IDO_ARZ` (`AVALI_AREZ_DEFEI_IDO`),
  KEY `FK_AVALI_AREZ_DEFEIG_IDO` (`AVALI_AREZ_DEFEIG_IDO`),
  KEY `FK_AVALI_AREZ_DEFEIS_IDO` (`AVALI_AREZ_DEFEIS_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_cliente_coleta
CREATE TABLE IF NOT EXISTS `rar_cliente_coleta` (
  `CLIEN_COL_PESSOA` decimal(10,0) NOT NULL DEFAULT '0',
  `CLIEN_COL_ENDER` varchar(100) DEFAULT NULL,
  `CLIEN_COL_BAIRRO` varchar(50) DEFAULT NULL,
  `CLIEN_COL_CIDADE` varchar(70) DEFAULT NULL,
  `CLIEN_COL_UF` char(2) DEFAULT NULL,
  `CLIEN_COL_FONE` varchar(15) DEFAULT NULL,
  `CLIEN_COL_DIAINI` char(1) DEFAULT NULL,
  `CLIEN_COL_DIAFIM` char(1) DEFAULT NULL,
  `CLIEN_COL_HRINI` datetime DEFAULT NULL,
  `CLIEN_COL_HRFIM` datetime DEFAULT NULL,
  `CLIEN_QTDELINHANF` decimal(2,0) DEFAULT NULL,
  `CLIEN_SEQ_RECLAMACAO` decimal(18,0) DEFAULT '1',
  `CLIEN_SEQ_SERVICO` decimal(18,0) NOT NULL DEFAULT '1',
  `CLIEN_COL_LOJAANT` decimal(10,0) DEFAULT NULL,
  `CLIEN_COL_LOJAANT_1` decimal(10,0) DEFAULT NULL,
  `CLIEN_COL_LOJAANT_2` decimal(10,0) DEFAULT NULL,
  `CLIEN_COL_LOJAANT_3` decimal(10,0) DEFAULT NULL,
  `CLIEN_COL_LOJAANT_4` decimal(10,0) DEFAULT NULL,
  `CLIEN_COB_BANCO` char(3) DEFAULT NULL,
  `CLIEN_COB_AGENCIA_CODIGO` varchar(10) DEFAULT NULL,
  `CLIEN_COB_AGENCIA_NOME` varchar(50) DEFAULT NULL,
  `CLIEN_COB_CONTA` varchar(20) DEFAULT NULL,
  `CLIEN_COB_TITULAR` varchar(50) DEFAULT NULL,
  `CLIEN_OPELJ_IDO` varchar(20) DEFAULT NULL,
  `CLIEN_COL_LOJAPROPRIA` int(11) NOT NULL DEFAULT '0',
  `CLIEN_COB2_BANCO` varchar(3) DEFAULT NULL,
  `CLIEN_COB2_AGENCIA_CODIGO` varchar(10) DEFAULT NULL,
  `CLIEN_COB2_AGENCIA_NOME` varchar(50) DEFAULT NULL,
  `CLIEN_COB2_CONTA` varchar(20) DEFAULT NULL,
  `CLIEN_COB2_TITULAR` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CLIEN_COL_PESSOA`),
  UNIQUE KEY `PK_CLIEN_COL_PESSOA` (`CLIEN_COL_PESSOA`),
  KEY `FK_CLIEN_COL_LOJAANT` (`CLIEN_COL_LOJAANT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_cliente_estrutura
CREATE TABLE IF NOT EXISTS `rar_cliente_estrutura` (
  `CLIEN_EST_CLIENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `CLIEN_EST_CONSULTOR` decimal(10,0) DEFAULT NULL,
  `CLIEN_EST_COORDENADOR` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`CLIEN_EST_CLIENTE`),
  KEY `IDX_CLIEN_EST_CLIENTE` (`CLIEN_EST_CLIENTE`),
  KEY `IDX_CLIEN_EST_COORDENADOR` (`CLIEN_EST_COORDENADOR`),
  KEY `IDX_CLIEN_EST_CONSULTOR` (`CLIEN_EST_CONSULTOR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_config
CREATE TABLE IF NOT EXISTS `rar_config` (
  `CONFIG_EMAIL_ASSISTENTE` varchar(150) DEFAULT NULL,
  `CONFIG_EMAIL_REVISOR` varchar(150) DEFAULT NULL,
  `CONFIG_EMAIL_GERENTE` varchar(150) DEFAULT NULL,
  `CONFIG_EMAIL_DIRETOR` varchar(150) DEFAULT NULL,
  `CONFIG_EMAIL_PRESIDENTE` varchar(150) DEFAULT NULL,
  `CONFIG_EMAIL_TRANSPORTADORA` varchar(150) DEFAULT NULL,
  `CONFIG_FR_LIMITECOLETA` int(11) NOT NULL DEFAULT '0',
  `CONFIG_MM_LIMITECOLETA` int(11) NOT NULL DEFAULT '0',
  `CONFIG_VINC_USUARIOXCLIENTE` datetime DEFAULT NULL,
  `CONFIG_DATAHORASINCRONIZACAO` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_contato
CREATE TABLE IF NOT EXISTS `rar_contato` (
  `CONT_IDO` varchar(20) NOT NULL DEFAULT '',
  `CONT_NOME` varchar(50) DEFAULT NULL,
  `CONT_EMAIL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CONT_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_defeito
CREATE TABLE IF NOT EXISTS `rar_defeito` (
  `DEFEI_IDO` varchar(20) NOT NULL DEFAULT '',
  `DEFEI_DESCRICAO` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DEFEI_IDO`),
  UNIQUE KEY `PK_DEFEI_IDO` (`DEFEI_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_defeito_grupo
CREATE TABLE IF NOT EXISTS `rar_defeito_grupo` (
  `DEFEIG_IDO` varchar(20) NOT NULL DEFAULT '',
  `DEFEIG_CATEGORIA` char(1) NOT NULL DEFAULT '1',
  `DEFEIG_DESCRICAO` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DEFEIG_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_defeito_subgrupo
CREATE TABLE IF NOT EXISTS `rar_defeito_subgrupo` (
  `DEFEIS_IDO` varchar(20) NOT NULL DEFAULT '',
  `DEFEIS_DEFEIG_IDO` varchar(20) DEFAULT NULL,
  `DEFEIS_DESCRICAO` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DEFEIS_IDO`),
  KEY `FK_DEFEIS_DEFEIG_IDO` (`DEFEIS_DEFEIG_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_etiqueta
CREATE TABLE IF NOT EXISTS `rar_etiqueta` (
  `ETIQ_NUMRAR` varchar(11) NOT NULL DEFAULT '',
  `ETIQ_REFERENCIA` varchar(19) DEFAULT NULL,
  `ETIQ_FABRICA` varchar(50) DEFAULT NULL,
  `ETIQ_USUAR_IDO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ETIQ_NUMRAR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_fabrica
CREATE TABLE IF NOT EXISTS `rar_fabrica` (
  `FABRI_IDO` varchar(20) NOT NULL DEFAULT '',
  `FABRI_PESSOA` decimal(10,0) DEFAULT NULL,
  `FABRI_CODSOLA` char(4) DEFAULT NULL,
  `FABRI_AGENT_IDO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`FABRI_IDO`),
  UNIQUE KEY `PK_FABRI_IDO` (`FABRI_IDO`),
  KEY `FK_RAR_FABRICA_PESSOA` (`FABRI_PESSOA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_item
CREATE TABLE IF NOT EXISTS `rar_item` (
  `ITEM_NUMRAR` varchar(12) NOT NULL DEFAULT '',
  `ITEM_NUMITEM` decimal(5,0) NOT NULL DEFAULT '0',
  `ITEM_PESSOA_EMITENTE` decimal(10,0) DEFAULT NULL,
  `ITEM_COLECAO` varchar(7) DEFAULT NULL,
  `ITEM_REFERENCIA` varchar(19) DEFAULT NULL,
  `ITEM_NF` varchar(6) DEFAULT NULL,
  `ITEM_SERIE` char(3) DEFAULT NULL,
  `ITEM_DATA` date DEFAULT NULL,
  `ITEM_VALOR` decimal(18,5) NOT NULL DEFAULT '0.00000',
  `ITEM_VALOR_ROYALTIE` decimal(18,5) DEFAULT '0.00000',
  `ITEM_QTDE` decimal(5,0) NOT NULL DEFAULT '0',
  `ITEM_FOTOPROD` varchar(150) DEFAULT NULL,
  `ITEM_FOTOSOLA` varchar(150) DEFAULT NULL,
  `ITEM_FOTODEFEITO` varchar(150) DEFAULT NULL,
  `ITEM_PAR` char(2) DEFAULT NULL,
  `ITEM_NUM33` char(3) DEFAULT '0',
  `ITEM_NUM34` char(3) DEFAULT '0',
  `ITEM_NUM35` char(3) DEFAULT '0',
  `ITEM_NUM36` char(3) DEFAULT '0',
  `ITEM_NUM37` char(3) DEFAULT '0',
  `ITEM_NUM38` char(3) DEFAULT '0',
  `ITEM_NUM39` char(3) DEFAULT '0',
  `ITEM_NUM40` char(3) DEFAULT '0',
  PRIMARY KEY (`ITEM_NUMITEM`,`ITEM_NUMRAR`),
  UNIQUE KEY `PK_ITEM_NUMRAR` (`ITEM_NUMITEM`,`ITEM_NUMRAR`),
  KEY `ID_ITEM1` (`ITEM_PAR`),
  KEY `ID_ITEM2` (`ITEM_REFERENCIA`),
  KEY `ID_ITEM3` (`ITEM_NUMRAR`,`ITEM_REFERENCIA`),
  KEY `FK_RAR_ITEM_PESSOA_EMITENTE` (`ITEM_PESSOA_EMITENTE`),
  KEY `ID_ITEM4` (`ITEM_NUMRAR`),
  KEY `ID_ITEM5` (`ITEM_NF`,`ITEM_SERIE`,`ITEM_REFERENCIA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_lancamento
CREATE TABLE IF NOT EXISTS `rar_lancamento` (
  `LANCA_NUMRAR` varchar(12) NOT NULL DEFAULT '',
  `LANCA_PESSOA` decimal(10,0) NOT NULL DEFAULT '0',
  `LANCA_PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `LANCA_FABRI_IDO` decimal(10,0) NOT NULL DEFAULT '0',
  `LANCA_DATAABERTURA` date DEFAULT NULL,
  `LANCA_SOLICITANTE` varchar(150) DEFAULT NULL,
  `LANCA_STATUS` char(1) DEFAULT '1',
  `LANCA_MOTIVO` blob,
  `LANCA_DATACANCELAMENTO` date DEFAULT NULL,
  `LANCA_USUAR_IDO_CANCELAMENTO` varchar(20) DEFAULT NULL,
  `LANCA_CLIENTE_NOME` varchar(150) DEFAULT NULL,
  `LANCA_CLIENTE_FONE` varchar(30) DEFAULT NULL,
  `LANCA_TIPORECLAMACAO` char(1) DEFAULT 'C',
  `LANCA_CATEGORIA` char(1) NOT NULL DEFAULT '1',
  `LANCA_PRENFI_IDO` varchar(9) DEFAULT NULL,
  `LANCA_TIPO` varchar(1) NOT NULL DEFAULT 'F',
  `LANCA_NBLOCO_ANALISE` varchar(255) NOT NULL,
  PRIMARY KEY (`LANCA_NUMRAR`),
  UNIQUE KEY `PK_LANCA_NUMRAR` (`LANCA_NUMRAR`),
  KEY `ID_LANCA4` (`LANCA_NUMRAR`,`LANCA_DATAABERTURA`),
  KEY `FK_CRAR_LANCAMENTO_LANCA_FABRI_` (`LANCA_FABRI_IDO`),
  KEY `FK_RAR_LANCAMENTO_USUAR_IDO` (`LANCA_USUAR_IDO_CANCELAMENTO`),
  KEY `FK_RAR_LANCAMENTO_PESSOA_EMITEN` (`LANCA_PESSOA_EMITENTE`),
  KEY `FK_RAR_LANCAMENTO_PESSOA` (`LANCA_PESSOA`),
  KEY `ID_LANCA_5` (`LANCA_PRENFI_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_log
CREATE TABLE IF NOT EXISTS `rar_log` (
  `LOG_USUAR_IDO` varchar(20) DEFAULT NULL,
  `LOG_SOLICITANTE` varchar(50) DEFAULT NULL,
  `LOG_MOTIVO` text,
  `LOG_TIPO` char(1) DEFAULT NULL,
  `LOG_NUMERO` varchar(20) DEFAULT NULL,
  `LOG_DATA` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_logemail
CREATE TABLE IF NOT EXISTS `rar_logemail` (
  `LOG_CONT_IDO` text,
  `LOG_MENSAGEM` text,
  `LOG_LANCA_NUMRAR` varchar(11) DEFAULT NULL,
  `LOG_USUAR_IDO` varchar(20) DEFAULT NULL,
  `LOG_DATA` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_material_grupo
CREATE TABLE IF NOT EXISTS `rar_material_grupo` (
  `MATERG_IDO` varchar(20) NOT NULL DEFAULT '',
  `MATERG_CATEGORIA` char(1) NOT NULL DEFAULT '1',
  `MATERG_DESCRICAO` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MATERG_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_operadorloja
CREATE TABLE IF NOT EXISTS `rar_operadorloja` (
  `OPELJ_IDO` varchar(20) NOT NULL DEFAULT '',
  `OPELJ_NOME` varchar(50) DEFAULT NULL,
  `OPELJ_EMAIL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`OPELJ_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_operadorlojacliente
CREATE TABLE IF NOT EXISTS `rar_operadorlojacliente` (
  `CODIGOLOJA` varchar(20) NOT NULL DEFAULT '',
  `NOMEOPERADOR` varchar(100) DEFAULT NULL,
  `EMAILOPERADOR` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CODIGOLOJA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_prenf
CREATE TABLE IF NOT EXISTS `rar_prenf` (
  `PRENF_NUMPRENF` varchar(10) NOT NULL DEFAULT '',
  `PRENF_PESSOA_EMITENTE` decimal(10,0) NOT NULL DEFAULT '0',
  `PRENF_PESSOA_EMITENTE_ORIGINAL` decimal(10,0) DEFAULT NULL,
  `PRENF_PESSOA_DESTINATARIO` decimal(10,0) NOT NULL DEFAULT '0',
  `PRENF_AUTOR_NUMAUT` varchar(9) DEFAULT NULL,
  `PRENF_CFOP` varchar(20) DEFAULT NULL,
  `PRENF_NUMNFDEVOLUCAO` bigint(6) DEFAULT NULL,
  `PRENF_SERIE` char(3) DEFAULT NULL,
  `PRENF_ICMS` decimal(18,5) DEFAULT '0.00000',
  `PRENF_IPI` decimal(18,5) DEFAULT '0.00000',
  `PRENF_DATA_ENVIO` date DEFAULT NULL,
  `PRENF_DATA_NFDEVOLUCAO` date DEFAULT NULL,
  `PRENF_DATA_INFNFDEVOLUCACAO` date DEFAULT NULL,
  `PRENF_QTDEVOLUME` decimal(18,5) DEFAULT '0.00000',
  `PRENF_OBSTRANSPORTADORA` blob,
  `PRENF_CODIGOALMOXARIFADO` varchar(20) DEFAULT NULL,
  `PRENF_CODIGOOPERACAO` varchar(20) DEFAULT NULL,
  `PRENF_DATA_COLETA` date DEFAULT NULL,
  `PRENF_DATA_SOLIC_COLETA` date DEFAULT NULL,
  `PRENF_DATA_RECEBTO_COLETA` date DEFAULT NULL,
  `PRENF_DATA_RECEBTO_AREZZO` date DEFAULT NULL,
  `PRENF_DATA_IMPORT_AREZZO` date DEFAULT NULL,
  `PRENF_OPER_IDO` decimal(18,0) DEFAULT NULL,
  `PRENF_MOTIVODEVOLUCAO` text,
  `PRENF_STATUS` char(1) DEFAULT NULL,
  `PRENF_INATIVADO_DATA` date DEFAULT NULL,
  `PRENF_INATIVADO_USUARIO` varchar(20) DEFAULT NULL,
  `PRENF_CATEGORIA` char(1) DEFAULT '1',
  `PRENF_TIPO` varchar(1) NOT NULL DEFAULT 'F',
  PRIMARY KEY (`PRENF_NUMPRENF`),
  UNIQUE KEY `PK_PRENF_NUMPRENF` (`PRENF_NUMPRENF`),
  KEY `ID_PRENF3` (`PRENF_NUMNFDEVOLUCAO`,`PRENF_SERIE`),
  KEY `FK_RAR_PRENF_AUTOR_NUMAUT` (`PRENF_AUTOR_NUMAUT`),
  KEY `FK_RAR_PRENF_PESSOA_EMITENTE` (`PRENF_PESSOA_EMITENTE`),
  KEY `FK_RAR_PRENF_PESSOA_DESTINATARIO` (`PRENF_PESSOA_DESTINATARIO`),
  KEY `ID_PRENF4` (`PRENF_DATA_IMPORT_AREZZO`),
  KEY `ID_PRENF5` (`PRENF_NUMNFDEVOLUCAO`,`PRENF_PESSOA_DESTINATARIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_prenf_email
CREATE TABLE IF NOT EXISTS `rar_prenf_email` (
  `PRENFE_IDO` varchar(20) DEFAULT NULL,
  `PRENFE_NUMPRENF` varchar(20) DEFAULT NULL,
  `PRENFE_DATA` datetime DEFAULT NULL,
  `PRENFE_USUAR_IDO` varchar(20) DEFAULT NULL,
  `PRENFE_MENSAGEM` text NOT NULL,
  `PRENFE_REMETENTE` varchar(100) DEFAULT NULL,
  `PRENFE_DESTINATARIO` varchar(100) DEFAULT NULL,
  `PRENFE_EMAILVALIDO` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_prenf_item
CREATE TABLE IF NOT EXISTS `rar_prenf_item` (
  `PRENFI_IDO` varchar(9) NOT NULL DEFAULT '',
  `PRENFI_NUMPRENF` varchar(20) DEFAULT NULL,
  `PRENFI_REFERENCIA` varchar(19) DEFAULT NULL,
  `PRENFI_UNIDADE` varchar(20) DEFAULT NULL,
  `PRENFI_QUANTIDADE` decimal(18,5) NOT NULL DEFAULT '0.00000',
  `PRENFI_VALORUNITARIO` decimal(18,5) NOT NULL DEFAULT '0.00000',
  `PRENFI_CLASSIFICACAOFISCAL` varchar(20) DEFAULT NULL,
  `LANCA_NUMRAR` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`PRENFI_IDO`),
  UNIQUE KEY `PK_PRENFI_IDO` (`PRENFI_IDO`),
  KEY `ID_PRENFI2` (`PRENFI_REFERENCIA`),
  KEY `FK_RAR_PRENF_ITEM_LANCA_NUMRAR` (`LANCA_NUMRAR`),
  KEY `FK_RAR_PRENF_ITEM_PRENF_NUMPRENF` (`PRENFI_NUMPRENF`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_programa
CREATE TABLE IF NOT EXISTS `rar_programa` (
  `PROGR_CODIGO` varchar(30) NOT NULL DEFAULT '',
  `PROGR_DESCRICAO` varchar(100) DEFAULT NULL,
  `PROGR_TIPO` char(1) DEFAULT NULL,
  PRIMARY KEY (`PROGR_CODIGO`),
  UNIQUE KEY `PK_PROGR_CODIGO` (`PROGR_CODIGO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_relatorio
CREATE TABLE IF NOT EXISTS `rar_relatorio` (
  `usuar_ido` varchar(20) DEFAULT NULL,
  `texto1` varchar(200) DEFAULT NULL,
  `texto2` varchar(200) DEFAULT NULL,
  `texto3` varchar(200) DEFAULT NULL,
  `texto4` varchar(200) DEFAULT NULL,
  `texto5` varchar(200) DEFAULT NULL,
  `num1` decimal(15,5) DEFAULT NULL,
  `num2` decimal(15,5) DEFAULT NULL,
  `num3` decimal(15,5) DEFAULT NULL,
  `num4` decimal(15,5) DEFAULT NULL,
  `num5` decimal(15,5) DEFAULT NULL,
  `DATA1` datetime DEFAULT NULL,
  `DATA2` datetime DEFAULT NULL,
  `DATA3` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_tipoproduto
CREATE TABLE IF NOT EXISTS `rar_tipoproduto` (
  `TIPPR_IDO` int(11) NOT NULL,
  `TIPPR_DESCRICAO` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TIPPR_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_transportadoras
CREATE TABLE IF NOT EXISTS `rar_transportadoras` (
  `transp_ido` varchar(20) DEFAULT NULL,
  `transp_nome` varchar(50) DEFAULT NULL,
  `transp_email` varchar(100) DEFAULT NULL,
  `transp_contato` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_usuario
CREATE TABLE IF NOT EXISTS `rar_usuario` (
  `USUAR_IDO` varchar(20) NOT NULL DEFAULT '',
  `USUAR_NOME` varchar(50) DEFAULT NULL,
  `USUAR_LOGIN` varchar(20) DEFAULT NULL,
  `USUAR_SENHA` varchar(20) DEFAULT NULL,
  `USUAR_EMAIL1` varchar(150) DEFAULT NULL,
  `USUAR_EMAIL2` varchar(150) DEFAULT NULL,
  `USUAR_EMAILPADRAO` char(1) DEFAULT '1',
  `USUAR_BLOQUEADO` char(1) DEFAULT 'N',
  `USUAR_TIPOUSUARIO` char(1) NOT NULL DEFAULT 'A',
  `USUAR_ECONSULTOR` varchar(1) DEFAULT 'N',
  `USUAR_CONSU_PESSOA` decimal(10,0) DEFAULT NULL,
  `USUAR_RESPONSAVELAUTOMATIVO` varchar(1) DEFAULT NULL,
  `USUAR_ELOGISTICA` varchar(1) NOT NULL DEFAULT 'N',
  `USUAR_EFRANQUEADO` varchar(1) NOT NULL DEFAULT 'S',
  `USUAR_RECEBEAUTOVINCULACAO` varchar(1) NOT NULL DEFAULT 'N',
  `USUAR_ACESSATODACARTEIRA` varchar(1) NOT NULL DEFAULT 'N',
  `USUAR_ENVIAEMAILAUTOMATICO` varchar(1) NOT NULL DEFAULT 'N',
  `USUAR_MODULOPADRAO` varchar(1) NOT NULL DEFAULT '1',
  `USUAR_ENVIAEMAILRV` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USUAR_IDO`),
  UNIQUE KEY `PK_USUAR_IDO` (`USUAR_IDO`),
  KEY `USUARIO_ID1` (`USUAR_LOGIN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_usuarioxcliente
CREATE TABLE IF NOT EXISTS `rar_usuarioxcliente` (
  `USUCLI_IDO` varchar(20) NOT NULL DEFAULT '',
  `USUCLI_USUAR_IDO` varchar(20) DEFAULT NULL,
  `USUCLI_PESSOA` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`USUCLI_IDO`),
  UNIQUE KEY `PK_USUCLI_IDO` (`USUCLI_IDO`),
  KEY `FK_RAR_USUARIOXCLIENTE_PESSOA` (`USUCLI_PESSOA`),
  KEY `FK_RAR_USUARIOXCLIENTE_USUAR_IDO` (`USUCLI_USUAR_IDO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_usuarioxconsultor
CREATE TABLE IF NOT EXISTS `rar_usuarioxconsultor` (
  `USUCO_IDO` varchar(20) DEFAULT NULL,
  `USUCO_USUAR_IDO` varchar(20) DEFAULT NULL,
  `USUCO_PESSOA` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.rar_usuarioxfornecedor
CREATE TABLE IF NOT EXISTS `rar_usuarioxfornecedor` (
  `USUFOR_IDO` varchar(20) NOT NULL DEFAULT '',
  `USUFOR_USUAR_IDO` varchar(20) DEFAULT NULL,
  `USUFOR_PESSOA` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`USUFOR_IDO`),
  KEY `FK_USUFOR_USUAR_IDO` (`USUFOR_USUAR_IDO`),
  KEY `FK_USUFOR_PESSOA` (`USUFOR_PESSOA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.referencia_material
CREATE TABLE IF NOT EXISTS `referencia_material` (
  `RF_MATERIAL` varchar(16) NOT NULL,
  `DS_RF_MATERIAL` varchar(80) DEFAULT NULL,
  `CATEGORIA_MATERIAL` decimal(3,0) NOT NULL DEFAULT '0',
  `GRUPO_MATERIAL` decimal(3,0) NOT NULL DEFAULT '0',
  `SUBGRUPO_MATERIAL` decimal(3,0) NOT NULL DEFAULT '0',
  `CD_UNIDADE_DE_N` char(3) DEFAULT NULL,
  KEY `IDX_REFERENCIAMATERIAL_01` (`RF_MATERIAL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.


-- Copiando estrutura para tabela dbWEBDEVOL.temp_solicitacao
CREATE TABLE IF NOT EXISTS `temp_solicitacao` (
  `SERSM_IDO` varchar(20) DEFAULT NULL,
  `SERSM_DESCRICAO` varchar(100) DEFAULT NULL,
  `SERSM_REFERENCIA` varchar(20) DEFAULT NULL,
  `SERSM_QUANTIDADE` decimal(10,0) DEFAULT '0',
  `SERSM_SERVI_NUMERO` varchar(12) DEFAULT NULL,
  `SERSM_ENTREGUE` char(1) NOT NULL DEFAULT 'N',
  `SERSM_FABRICANTE` decimal(10,0) DEFAULT NULL,
  `SERSM_MATERG_IDO` varchar(20) DEFAULT NULL,
  `SERSM_IMAGEM` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
